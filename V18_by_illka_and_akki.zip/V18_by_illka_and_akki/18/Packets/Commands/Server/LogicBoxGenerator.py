from ast import excepthandler
from random import randint, choice
class Gen():
    def GeneratorLoot(self, boxes):
        commonbrawlers = [0, 1, 2, 3, 7, 8, 9, 14]
        rarebrawlers = [6, 10, 13, 24]
        superrarebrawlers = [4, 18, 19, 25]
        epicbrawlers = [15, 16, 20]
        mythicbrawlers = [11, 17, 21]
        legendarybrawlers = [5, 12, 23]
        starpowers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 23, 24, 25]
        commonbrawlersunlockable = []
        rarebrawlersunlockable = []
        superrarebrawlersunlockable = []
        epicbrawlersunlockable = []
        mythicbrawlersunlockable = []
        legendarybrawlersunlockable = []
        unlocked_brawlers = []
        unlockable_brawlers = []
        unlocked_starpowers = []
        starpower_unlockable = []

        for brawlers_id in self.player.BrawlersUnlockedState:
            if self.player.BrawlersUnlockedState[brawlers_id] != 1: #CREATED BY KARM(tg: @emerald011)
                brawlers_id = int(brawlers_id)
                if brawlers_id in commonbrawlers:
                    commonbrawlersunlockable.append(int(brawlers_id))
                elif brawlers_id in rarebrawlers:
                    rarebrawlersunlockable.append(int(brawlers_id))
                elif brawlers_id in superrarebrawlers:
                    superrarebrawlersunlockable.append(int(brawlers_id))
                elif brawlers_id in epicbrawlers:
                    epicbrawlersunlockable.append(int(brawlers_id))
                elif brawlers_id in mythicbrawlers:
                    mythicbrawlersunlockable.append(int(brawlers_id))
                elif brawlers_id in legendarybrawlers:
                    legendarybrawlersunlockable.append(int(brawlers_id))
            else:
                if self.player.Brawler_level[brawlers_id] != 8:
                    unlocked_brawlers.append(int(brawlers_id))
        
        for brawlers_id in self.player.Brawler_starPower:
            if self.player.Brawler_starPower[brawlers_id] == 0 and self.player.BrawlersUnlockedState[brawlers_id] == 1 and self.player.Brawler_level[brawlers_id] == 8:
                brawlers_id = int(brawlers_id)
                if brawlers_id in starpowers:
                    starpower_unlockable.append(int(brawlers_id))
            else:
                if self.player.Brawler_starPower[brawlers_id] == 1:
                    unlocked_starpowers.append(int(brawlers_id))
        
        rews = {
            "Gold": 0,
            "Points": [],
            "brawlers": [],
            "starpower": [],
            "bonuses": [
                {
                    "type": "gems",
                    "multiplier": 0
                },
                {
                    "type": "doublers",
                    "multiplier": 0
                },
                {
                    "type": "tickets",
                    "multiplier": 0
                }
            ],
            "rewards": 0
        }
        cardsi = 0
        
        for i in range(boxes):
            randbrawler = randint(1, 7500)
            randstarpower = randint(1, 1000)
            #CREATED BY KARM(tg: @emerald011)
            randgold = randint(30, 60)
            randcards = randint(12, 26)
            rews["Gold"] += randgold
            cardsi += randcards
            #B R A W L E R S
            if randbrawler <= 10:
                if len(legendarybrawlersunlockable) == 0:
                    pass
                else:
                    rand_brawler = choice(legendarybrawlersunlockable)
                    legendarybrawlersunlockable.remove(rand_brawler)
                    listt = list(rews["brawlers"])
                    listt.append(rand_brawler)
                    rews["brawlers"] = listt
                    rews["rewards"] += 1
                    rews["Gold"] -= randgold
                    cardsi -= randcards
            elif randbrawler <= 25:
                if len(mythicbrawlersunlockable) == 0:
                    pass
                else:
                    rand_brawler = choice(mythicbrawlersunlockable)
                    mythicbrawlersunlockable.remove(rand_brawler)
                    listt = list(rews["brawlers"])
                    listt.append(rand_brawler)
                    rews["brawlers"] = listt
                    rews["rewards"] += 1
                    rews["Gold"] -= randgold
                    cardsi -= randcards
            elif randbrawler <= 70:
                if len(epicbrawlersunlockable) == 0:
                    pass
                else:
                    rand_brawler = choice(epicbrawlersunlockable)
                    epicbrawlersunlockable.remove(rand_brawler)
                    listt = list(rews["brawlers"])
                    listt.append(rand_brawler)
                    rews["brawlers"] = listt
                    rews["rewards"] += 1
                    rews["Gold"] -= randgold
                    cardsi -= randcards
            elif randbrawler <= 200:
                if len(superrarebrawlersunlockable) == 0:
                    pass
                else:
                    rand_brawler = choice(superrarebrawlersunlockable)
                    superrarebrawlersunlockable.remove(rand_brawler)
                    listt = list(rews["brawlers"])
                    listt.append(rand_brawler)
                    rews["brawlers"] = listt
                    rews["rewards"] += 1
                    rews["Gold"] -= randgold
                    cardsi -= randcards
            elif randbrawler <= 400:
                if len(rarebrawlersunlockable) == 0:
                    pass
                else:
                    rand_brawler = choice(rarebrawlersunlockable)
                    #CREATED BY KARM(tg: @emerald011)
                    rarebrawlersunlockable.remove(rand_brawler)
                    listt = list(rews["brawlers"])
                    listt.append(rand_brawler)
                    rews["brawlers"] = listt
                    rews["rewards"] += 1
                    rews["Gold"] -= randgold
                    cardsi -= randcards
            elif randbrawler <= -1:
                if len(commonbrawlersunlockable) == 0:
                    pass
                else:
                    rand_brawler = choice(commonbrawlersunlockable)
                    commonbrawlersunlockable.remove(rand_brawler)
                    listt = list(rews["brawlers"])
                    listt.append(rand_brawler)
                    rews["brawlers"] = listt
                    rews["rewards"] += 1
                    rews["Gold"] -= randgold
                    cardsi -= randcards
            else:
                pass
            #S T A R P O W E R S
            if randstarpower < 10:
                if len(starpower_unlockable) == 0:
                    pass
                else:
                    rand_brawler = choice(starpower_unlockable)
                    starpower_unlockable.remove(rand_brawler)
                    listt = list(rews["starpower"])
                    listt.append(rand_brawler)
                    rews["starpower"] = listt
                    rews["rewards"] += 1
                    rews["Gold"] -= randgold
                    cardsi -= randcards
            else:
                pass

        if rews["Gold"] == 0:
            return rews
        else:
            rews["rewards"] += 1

        #P O I N T S
        if boxes == 1:
            cards = []
            for i in range(2):
                try:
                    if i != 4:
                        if cardsi <= 20:
                            var = randint(5, 15)
                        else:
                            var = randint(10, int(cardsi / 2))
                            #CREATED BY KARM(tg: @emerald011)
                            cardsi -= var
                    else:
                        var = cardsi
                    cards.append(var)
                except Exception as error:
                    break
            cards.sort()
            lens = len(unlocked_brawlers)
            if lens > 2:
                lens = 2
            for i in range(lens):
                brawler = choice(unlocked_brawlers)
                unlocked_brawlers.remove(brawler)
                inf = {
                    "brawler": brawler,
                    "multiplier": cards[0]
                }
                cards.pop(0)
                rews["Points"].append(inf)
                rews["rewards"] += 1
        elif boxes == 3:
            cards = []
            for i in range(3):
                try:
                    if i != 4:
                        if cardsi <= 20:
                            var = randint(5, 15)
                        else:
                            var = randint(10, int(cardsi / 2))
                            #CREATED BY KARM(tg: @emerald011)
                            cardsi -= var
                    else:
                        var = cardsi
                    cards.append(var)
                except Exception as error:
                    break
            cards.sort()
            lens = len(unlocked_brawlers)
            if lens > 3:
                lens = 3
            for i in range(lens):
                brawler = choice(unlocked_brawlers)
                unlocked_brawlers.remove(brawler)
                inf = {
                    "brawler": brawler,
                    "multiplier": cards[0]
                }
                cards.pop(0)
                rews["Points"].append(inf)
                rews["rewards"] += 1
        elif boxes == 10:
            cards = []
            for i in range(5):
                try:
                    if i != 4:
                        if cardsi <= 20:
                            var = randint(5, 15)
                        else:
                            var = randint(10, int(cardsi / 2))
                            #CREATED BY KARM(tg: @emerald011)
                            cardsi -= var
                    else:
                        var = cardsi
                    cards.append(var)
                except Exception as error:
                    break
            cards.sort()
            lens = len(unlocked_brawlers)
            if lens > 5:
                lens = 5
            for i in range(lens):
                brawler = choice(unlocked_brawlers)
                unlocked_brawlers.remove(brawler)
                inf = {
                    "brawler": brawler,
                    "multiplier": cards[0]
                }
                cards.pop(0)
                rews["Points"].append(inf)
                rews["rewards"] += 1
        else:
            pass
        if len(cards) > 0:
            for i in range(len(cards)):
                allca = 0
                allca += cards[i]
        else:
            pass
        if len(rews["Points"]) != 0 and lens < 5:
            allca = 20
            caef = int(allca / len(rews["Points"]))
            for i in range(len(rews["Points"])):
                rews["Points"][i]["multiplier"] += caef
        else:
            pass

        #B O N U S E S
        for i in range(boxes):
            randbonus = randint(1, 5)
            if randbonus == 1:
                randbon = randint(1, 11)
                if randbon == 10:
                    gems = randint(3, 10)
                    rews["bonuses"][0]["multiplier"] += gems
                elif randbon == 7:
                    rews["bonuses"][1]["multiplier"] += 200
                else:
                    tickets = choice([3, 5, 7, 10, 15])
                    rews["bonuses"][2]["multiplier"] + tickets
        if rews["bonuses"][0]["multiplier"] > 0:
            rews["rewards"] += 1
        else:
            pass
        if rews["bonuses"][1]["multiplier"] > 0:
            rews["rewards"] += 1
        else:
            pass
        if rews["bonuses"][2]["multiplier"] > 0:
            rews["rewards"] += 1
        else:
            #CREATED BY KARM(tg: @emerald011)
            pass
        return rews