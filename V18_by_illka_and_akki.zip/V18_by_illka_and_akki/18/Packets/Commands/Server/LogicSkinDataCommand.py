from random import *
from Database.DatabaseManager import DataBase
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from Logic.Boxes import Boxes

from Utils.Writer import Writer
from Database.DatabaseManager import DataBase


class LogicSkinDataCommand(Writer):

    def __init__(self, client, player, ID):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.BoxData = Boxes.boxes
        self.skin = ID

    def encode(self):
        self.writeVint(203) # Command
        self.writeVint(0)
        self.writeVint(1) # Multipler
        self.writeVint(100)
        self.writeVint(1) # Reward Count

        self.writeVint(1) # Value
        self.writeVint(0) # ScId
        self.writeVint(9) # Reward ID
        self.writeScId(29, self.skin) # ScId
        self.player.UnlockedSkins.append(self.skin)
        DataBase.replaceValue(self, "UnlockedSkins", self.player.UnlockedSkins)
        if self.skin in [29, 15, 27]:
            self.player.gems -= 30
            DataBase.replaceValue(self, "gems", self.player.gems)
        elif self.skin in [64, 25, 47, 58, 5, 57, 28, 88, 45, 11, 20]:
            self.player.gems -= 80
            DataBase.replaceValue(self, "gems", self.player.gems)
        elif self.skin in [79, 44, 30, 71, 26, 68, 50, 75]:
            self.player.gems -= 150
            DataBase.replaceValue(self, "gems", self.player.gems)
        elif self.skin == 49:
            self.player.gems -= 300
            DataBase.replaceValue(self, "gems", self.player.gems)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(1)
        self.writeVint(0)
        self.writeVint(0)
        